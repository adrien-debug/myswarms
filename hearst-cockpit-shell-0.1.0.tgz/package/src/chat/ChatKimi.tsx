"use client";

/**
 * ChatKimi.tsx — Chat Kimi 2.6 embarqué dans le RailRight.
 *
 * Merge des 3 versions :
 *   - Codex : markdown riche via DOMPurify, ChatPersistence, retry, skeleton.
 *   - Lumière : filtrage `<think>...</think>` côté stream (server-side fait
 *     le gros du travail, on garde un filet côté client au cas où).
 *   - Hub : props optionnelles `productName` + `productColor` pour le contexte.
 *
 * Cycle de vie : `AbortController` annulé au démontage + à chaque nouveau send.
 *
 * Persistance : si `persistence` est fourni via `<CockpitShell chatConfig>`,
 * `loadMessages` / `saveMessage` / `createChat` sont appelés. Sinon = mémoire
 * locale (volatile).
 */

import {
  type KeyboardEvent,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import DOMPurify from "dompurify";
import {
  subscribe,
  getSnapshot,
  getServerSnapshot,
} from "../stores/activeProductStore";
import { useSyncExternalStore } from "react";
import { useCockpit } from "../shell/context";
import type { ChatMessage } from "./types";

// ---------------------------------------------------------------------------
// Markdown léger — pas de lib lourde
// ---------------------------------------------------------------------------

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderMarkdown(text: string): string {
  return (
    text
      // Blocs code (``` ... ```)
      .replace(
        /```(\w*)\n?([\s\S]*?)```/g,
        (_m, _lang: string, code: string) =>
          `<pre style="background:rgba(0,0,0,0.4);padding:8px 10px;border-radius:6px;overflow-x:auto;font-size:12px;margin:6px 0;border:1px solid rgba(255,255,255,0.08)"><code>${escapeHtml(code.trimEnd())}</code></pre>`,
      )
      // Code inline
      .replace(
        /`([^`]+)`/g,
        (_m, c: string) =>
          `<code style="background:rgba(0,0,0,0.35);padding:1px 5px;border-radius:3px;font-size:12px">${escapeHtml(c)}</code>`,
      )
      // Gras
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      // Italique
      .replace(/\*(.+?)\*/g, "<em>$1</em>")
      // Listes
      .replace(/((?:^[-*] .+$\n?)+)/gm, (block) => {
        const items = block
          .split("\n")
          .filter(Boolean)
          .map(
            (line) =>
              `<li style="margin:2px 0">${line.replace(/^[-*] /, "")}</li>`,
          )
          .join("");
        return `<ul style="padding-left:16px;margin:4px 0">${items}</ul>`;
      })
      // Sauts de ligne
      .replace(/\n/g, "<br>")
  );
}

function sanitizeHtml(html: string): string {
  if (typeof window === "undefined") return "";
  return DOMPurify.sanitize(html);
}

function generateId(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

/**
 * Filtre stream-safe des blocs `<think>...</think>` (raisonnement interne
 * Kimi non destiné à l'utilisateur). Reprise de la logique Lumière, adaptée
 * en générateur sur un buffer string accumulant les chunks.
 */
function makeThinkStripper() {
  let buffer = "";
  let inThink = false;

  return function feed(chunk: string): string {
    buffer += chunk;
    let output = "";
    let i = 0;

    while (i < buffer.length) {
      if (!inThink) {
        const openIdx = buffer.indexOf("<think>", i);
        if (openIdx === -1) {
          const tail = buffer.slice(i);
          // Hold back tout suffixe susceptible d'être un prefix de '<think>'.
          const OPEN_TAG = "<think>";
          let holdLen = 0;
          for (
            let prefLen = Math.min(OPEN_TAG.length - 1, tail.length);
            prefLen > 0;
            prefLen--
          ) {
            if (tail.endsWith(OPEN_TAG.slice(0, prefLen))) {
              holdLen = prefLen;
              break;
            }
          }
          output += tail.slice(0, tail.length - holdLen);
          i = buffer.length;
          buffer = holdLen > 0 ? tail.slice(tail.length - holdLen) : "";
          return output;
        }
        output += buffer.slice(i, openIdx);
        inThink = true;
        i = openIdx + 7; // skip '<think>'
      } else {
        const closeIdx = buffer.indexOf("</think>", i);
        if (closeIdx === -1) {
          // Pas de fermeture dans le buffer — on garde tout pour le prochain feed.
          buffer = buffer.slice(i);
          return output;
        }
        inThink = false;
        i = closeIdx + 8; // skip '</think>'
      }
    }
    buffer = "";
    return output;
  };
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export interface ChatKimiProps {
  /** Nom du produit en cours, pour le placeholder/contexte. */
  productName?: string;
  /** Accent du produit, pour la pastille + bouton envoyer. */
  productColor?: string;
}

export function ChatKimi({ productName, productColor }: ChatKimiProps = {}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState<string>("");
  const [streaming, setStreaming] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [chatId, setChatId] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const activeProduct = useSyncExternalStore(
    subscribe,
    getSnapshot,
    getServerSnapshot,
  );
  const { chatConfig } = useCockpit();
  const endpoint = chatConfig.apiEndpoint ?? "/api/cockpit-chat";
  const persistence = chatConfig.persistence;

  // Charge l'historique d'une conversation existante au mount (si persistance).
  // biome-ignore lint/correctness/useExhaustiveDependencies: mount-only
  useEffect(() => {
    if (!persistence || !chatId) return;
    let cancelled = false;
    persistence
      .loadMessages(chatId)
      .then((loaded) => {
        if (!cancelled) setMessages(loaded);
      })
      .catch(() => {
        /* persistance KO : on reste en mémoire locale */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Auto-scroll
  // biome-ignore lint/correctness/useExhaustiveDependencies: scroll on messages update
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Annule tout stream au démontage.
  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  const newConversation = useCallback(() => {
    abortRef.current?.abort();
    setMessages([]);
    setError(null);
    setStreaming(false);
    setInput("");
    setChatId(null);
  }, []);

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || streaming) return;

      // Annuler le stream précédent.
      abortRef.current?.abort();

      setError(null);

      const userMsg: ChatMessage = {
        id: generateId(),
        role: "user",
        content: trimmed,
        createdAt: Date.now(),
      };

      const history = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      setMessages((prev) => [...prev, userMsg]);
      setInput("");

      // Placeholder assistant
      const assistantId = generateId();
      setMessages((prev) => [
        ...prev,
        {
          id: assistantId,
          role: "assistant",
          content: "",
          createdAt: Date.now(),
        },
      ]);
      setStreaming(true);

      const controller = new AbortController();
      abortRef.current = controller;

      // Best-effort : persiste le message user dès qu'on a un chatId.
      let effectiveChatId = chatId;
      if (persistence && !effectiveChatId) {
        try {
          effectiveChatId = await persistence.createChat();
          setChatId(effectiveChatId);
        } catch {
          /* createChat KO → on continue en mémoire seulement */
        }
      }
      if (persistence && effectiveChatId) {
        persistence.saveMessage(effectiveChatId, userMsg).catch(() => {});
      }

      const stripThink = makeThinkStripper();

      try {
        const resp = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chatId: effectiveChatId,
            message: trimmed,
            messages: history,
            productId: activeProduct,
          }),
          signal: controller.signal,
        });

        if (!resp.ok) {
          if (resp.status === 429) {
            throw new Error(
              "Trop de requêtes — réessaie dans quelques secondes.",
            );
          }
          const errData = (await resp
            .json()
            .catch(() => null)) as { error?: string } | null;
          throw new Error(errData?.error ?? `HTTP ${resp.status}`);
        }
        if (!resp.body) throw new Error("Pas de stream dans la réponse");

        const headerChatId = resp.headers.get("x-chat-id");
        if (headerChatId && headerChatId !== effectiveChatId) {
          effectiveChatId = headerChatId;
          setChatId(headerChatId);
        }

        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let assembled = "";

        let streamDone = false;
        while (!streamDone) {
          const { done, value } = await reader.read();
          streamDone = done;
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          const filtered = stripThink(chunk);
          if (filtered) {
            assembled += filtered;
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantId ? { ...m, content: assembled } : m,
              ),
            );
          }
        }

        // Flush final UTF-8 + filtre.
        const tail = stripThink(decoder.decode());
        if (tail) {
          assembled += tail;
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantId ? { ...m, content: assembled } : m,
            ),
          );
        }

        // Persiste la réponse assistant.
        if (persistence && effectiveChatId && assembled) {
          persistence
            .saveMessage(effectiveChatId, {
              id: assistantId,
              role: "assistant",
              content: assembled,
              createdAt: Date.now(),
            })
            .catch(() => {});
        }
      } catch (err) {
        if (err instanceof Error && err.name === "AbortError") return;
        const errMsg = err instanceof Error ? err.message : "Erreur inconnue";
        setError(errMsg);
        // Retire le placeholder vide
        setMessages((prev) => prev.filter((m) => m.id !== assistantId));
      } finally {
        setStreaming(false);
        abortRef.current = null;
        textareaRef.current?.focus();
      }
    },
    [streaming, messages, endpoint, persistence, chatId, activeProduct],
  );

  const handleKeyDown = useCallback(
    (e: KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        void sendMessage(input);
      }
    },
    [input, sendMessage],
  );

  const retryLast = useCallback(() => {
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    if (!lastUser) return;
    setMessages((prev) => prev.filter((m) => m.id !== lastUser.id));
    setError(null);
    void sendMessage(lastUser.content);
  }, [messages, sendMessage]);

  const accent = productColor ?? "var(--ct-accent, #8A1538)";

  return (
    <div className="ct-chat-root">
      {/* Action bar */}
      <div className="ct-chat-actionbar">
        <button
          type="button"
          onClick={newConversation}
          title="Nouvelle conversation"
          className="ct-chat-newbtn"
        >
          + Nouveau
        </button>
      </div>

      {/* Messages */}
      <div className="ct-chat-list" ref={bottomRef as never}>
        {messages.length === 0 && !streaming && (
          <p className="ct-placeholder">
            Assistant Kimi K2.6
            {productName ? ` — contexte ${productName}.` : "."}
            <br />
            Pose ta question pour démarrer.
          </p>
        )}

        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            msg={msg}
            isStreamingThis={
              streaming &&
              msg.role === "assistant" &&
              msg === messages[messages.length - 1]
            }
            accent={accent}
          />
        ))}

        {error && (
          <div className="ct-chat-error">
            <p>{error}</p>
            <button type="button" onClick={retryLast} className="ct-chat-retry">
              ↻ Réessayer
            </button>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form
        className="ct-chat-form"
        onSubmit={(e) => {
          e.preventDefault();
          void sendMessage(input);
        }}
      >
        <textarea
          ref={textareaRef}
          className="ct-chat-input"
          rows={2}
          placeholder="Message à Kimi…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={streaming}
        />
        <button
          type="submit"
          className="ct-chat-send"
          disabled={!input.trim() || streaming}
          aria-label="Envoyer"
          style={{ background: input.trim() && !streaming ? accent : undefined }}
        >
          {streaming ? "…" : "↑"}
        </button>
      </form>
    </div>
  );
}

// ---------------------------------------------------------------------------
// MessageBubble
// ---------------------------------------------------------------------------

interface MessageBubbleProps {
  msg: ChatMessage;
  isStreamingThis: boolean;
  accent: string;
}

function MessageBubble({ msg, isStreamingThis, accent }: MessageBubbleProps) {
  const isUser = msg.role === "user";
  const isEmpty = msg.content === "";

  return (
    <div className={`ct-chat-msg ${isUser ? "user" : "assistant"}`}>
      {isEmpty ? (
        <div className="ct-chat-typing">
          <span />
          <span />
          <span />
        </div>
      ) : isUser ? (
        <p style={{ whiteSpace: "pre-wrap" }}>{msg.content}</p>
      ) : (
        <>
          <div
            // biome-ignore lint/security/noDangerouslySetInnerHtml: sanitized via DOMPurify
            dangerouslySetInnerHTML={{
              __html: sanitizeHtml(renderMarkdown(msg.content)),
            }}
          />
          {isStreamingThis && (
            <span className="ct-chat-cursor" style={{ background: accent }} />
          )}
        </>
      )}
    </div>
  );
}

export default ChatKimi;
